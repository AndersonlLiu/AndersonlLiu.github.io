let config = {
    dbUrl:
      "mongodb+srv://root:root@books-store-mern.blh2kyz.mongodb.net/books-collection?retryWrites=true&w=majority",
  };
  
export default config;